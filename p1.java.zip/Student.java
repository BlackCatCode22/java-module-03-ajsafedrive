// aJ
// Student.java
// 9/11/25

public class Student {
    String firstName;
    String lastName;
    double gpa;
    String major;
    int age;
    boolean onProbabtion;

    int name = 8;

}
