package p2MyTest;

public class Games {
    String typeOfGame;

}
