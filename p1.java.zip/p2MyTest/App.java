package p2MyTest;

public class App {
    public static void main(String[] args) {


        Games Vidya = new Games();
        Vidya.typeOfGame = "The Finals";

        System.out.println("My favorite game to play is " + Vidya.typeOfGame);


    }
}