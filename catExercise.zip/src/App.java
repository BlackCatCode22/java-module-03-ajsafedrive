// aJ
// 9/18/25
// catExercise.zip
// App.java


// make class named App
public class App {
    // Make method Main
    public static void main(String[] args) {

        // make the cat object
        Cat myCat = new Cat();
        // assign name to Object variable name associated with myCat
        myCat.name = "Bumblebee";
        // Test
        System.out.println("Testing if " + myCat.name + " works");
        // assign a int to object variable associated with myCat
        myCat.age = 5;
        System.out.println("Testing if my cats age is working, age = " + myCat.age);
        myCat.Meow();



    }
}