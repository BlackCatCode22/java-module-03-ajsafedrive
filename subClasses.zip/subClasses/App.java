// aJ
// 9/16/2026
// Working with sub classes!

// create class
public class App {
    public static void main(String[] args) {


        // Create american object
        AmericanChef americanChef = new AmericanChef();
        americanChef.makeChicken();

        // create italian object
        ItalianChef italianChef = new ItalianChef();
        italianChef.makePasta();

        // create chinese object
        ChineseChef chineseChef = new ChineseChef();
        chineseChef.makeFriedRice();


    }
}