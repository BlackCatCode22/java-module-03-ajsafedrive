public class ItalianChef {

    // create method options 1
    public void makeChicken() {
        System.out.println("The Italian Chef makes a delicious chicken");

    }
    // create method options 2
    public void makeSpecialDish() {
        System.out.println("The Italian Chef makes a special dish");
    }
    // create method options 3
    public void makePasta() {
        System.out.println("The Italian Chef makes authentic pasta!");
    }
    // create method options 4
    public void makeFriedRice() {
        System.out.println("This Italian Chef makes fried rice");
    }
}



