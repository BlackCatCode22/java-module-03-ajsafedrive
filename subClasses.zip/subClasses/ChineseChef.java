public class ChineseChef {

    // create method options 1
    public void makeChicken() {
        System.out.println("The Chinese Chef makes a delicious chicken");
    }
    // create method options 2
    public void makeSpecialDish() {
        System.out.println("The Chinese Chef makes a special dish");
    }
    // create method options 3
    public void makePasta() {
        System.out.println("The Chinese Chef makes pasta");
    }
    // create method options 4
    public void makeFriedRice() {
        System.out.println("This Chinese Chef makes authentic  fried rice");
    }
}




