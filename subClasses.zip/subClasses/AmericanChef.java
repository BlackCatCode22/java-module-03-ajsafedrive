public class AmericanChef {

    // create method options 1
    public void makeChicken() {
        System.out.println("The American Chef makes chicken");
    }
    // create method options 2
    public void makeSpecialDish() {
        System.out.println("The American Chef makes a special dish");
    }
    // create method options 3
    public void makePasta() {
        System.out.println("The American Chef makes pasta");
    }
    // create method options 4
    public void makeFriedRice() {
        System.out.println("This American Chef makes fried rice");
    }
}
