// Functionality extended from the Chef.java class
public class ChineseChef extends Chef {

    public void makeFriedRice() {
        System.out.println("The Chinese Chef makes authentic fried rice");
    }
    public void makeSpecialDish() {
        System.out.println("The Chef makes his special dish orange chicken");
    }
}




