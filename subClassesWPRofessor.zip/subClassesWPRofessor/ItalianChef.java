// Functionality extended from the Chef.java class
public class ItalianChef extends Chef {

    public void makePasta() {
        System.out.println("The Italian Chef makes authentic pasta!");
    }
    public void makeSpecialDish() {
        System.out.println("The Chef makes his special dish carbonara!");
    }
}



