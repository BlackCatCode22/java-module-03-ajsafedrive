
public class App {
    public static void main(String[] args) {
        // My code will be submitted in a seperate github commit, as this one is working with the class.
        System.out.println("Playing with Subclasses - This is the code I did following the professor");

        // Create american object
        Chef chef = new Chef();
        chef.makeSalad();

        // create italian object
        ItalianChef italianChef = new ItalianChef();
        italianChef.makePasta();

        // create chinese object
        ChineseChef chineseChef = new ChineseChef();
        chineseChef.makeFriedRice();

        //Special Chinese Dish
        ChineseChef chineseChefSpecial = new ChineseChef();
        chineseChefSpecial.makeSpecialDish();

        //Special Italian Dish
        ItalianChef italianChefSpecial = new ItalianChef();
        italianChefSpecial.makeSpecialDish();

    }


}