public class Chef {

    // create method options 1
    public void makeSalad() {
        System.out.println("The Chef makes Salad");
    }
    // create method options 2
    public void makeSpecialDish() {
        System.out.println("The Chef makes bbq ribs");
    }



}
